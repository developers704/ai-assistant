import { NextRequest, NextResponse } from "next/server";

import { v4 as uuidv4 } from "uuid";

import { getState, setState, clearChatHistory } from "@/lib/store/server-store";

import { getEnrichedState } from "@/lib/google/sync";

import {
  processMessage,
  executeSideEffects,
  shouldUseRuleEngine,
  isGeneralKnowledgeChatQuery,
} from "@/lib/ai/assistant-engine";

import { isLLMChatConfigured, processMessageWithLLM } from "@/lib/ai/llm-chat";
import { isImageGenerateRequest } from "@/lib/images/generate-jewellery-image";
import { processImageGenerate } from "@/lib/ai/image-generate";

import { processAlexaMessage } from "@/lib/ai/process-message";
import { processAlexaTurn } from "@/lib/alexa/orchestrator";
import { AlexaFlags } from "@/lib/alexa/flags";
import { appendConversationSummary } from "@/lib/memory/store";
import { clientAppState } from "@/lib/auth/client-state";
import type { AIResponse, ChatMessage } from "@/types";

export const runtime = "nodejs";
export const maxDuration = 120;

async function resolveResponse(
  message: string,
  state: Awaited<ReturnType<typeof getEnrichedState>>
): Promise<{
  response: AIResponse;
  engine: "rules" | "llm" | "llm-fallback" | "router" | "orchestrator";
}> {
  // Hybrid: clear app intents stay on rules (fast + accurate numbers).
  // General knowledge / chitchat skip router so they always hit the LLM.
  if (shouldUseRuleEngine(message, state)) {
    return { response: processMessage(message, state), engine: "rules" };
  }

  const preferLlm =
    isLLMChatConfigured() && isGeneralKnowledgeChatQuery(message);

  // Unified orchestrator path (feature-flagged) — skip for world-knowledge Qs
  if (!preferLlm && AlexaFlags.unifiedOrchestrator()) {
    const turn = await processAlexaTurn({
      channel: "chat",
      conversationId: "chat-main",
      message,
      currentRoute: state.uiContext?.currentPath,
    });

    if (!turn.deferToLegacy && turn.textAnswer) {
      return {
        response: {
          intent: "general",
          message: turn.textAnswer,
          speak: true,
          pendingAction: state.pendingActions[0],
          data: turn.uiAction?.route
            ? {
                navigate: turn.uiAction.route,
                filters: turn.uiAction.filters,
                alexaDomain: turn.intent.domain,
                alexaAction: turn.intent.action,
              }
            : {
                alexaDomain: turn.intent.domain,
                alexaAction: turn.intent.action,
              },
        },
        engine: "orchestrator",
      };
    }
  }

  if (!preferLlm) {
    const routed = await processAlexaMessage(message, state);
    if (routed) {
      return { response: routed, engine: "router" };
    }
  }

  if (isImageGenerateRequest(message)) {
    return { response: await processImageGenerate(message), engine: "rules" };
  }

  if (isLLMChatConfigured()) {
    try {
      return {
        response: await processMessageWithLLM(message, state),
        engine: "llm",
      };
    } catch (err) {
      console.error("LLM chat failed:", err);
      // Never dump the old "I can help with emails…" canned line for Q&A.
      return {
        response: {
          intent: "general",
          message:
            "I hit a temporary issue answering that. Please try again in a moment.",
          speak: true,
        },
        engine: "llm-fallback",
      };
    }
  }

  return { response: processMessage(message, state), engine: "rules" };
}

export async function POST(req: NextRequest) {
  const { message } = await req.json();

  if (!message?.trim()) {
    return NextResponse.json({ error: "Message required" }, { status: 400 });
  }

  const trimmed = message.trim();

  // Quick enrich — never block chat on a cold Google sync
  const state = await getEnrichedState({ quick: true });

  const userMessage: ChatMessage = {
    id: uuidv4(),
    role: "user",
    content: trimmed,
    timestamp: new Date().toISOString(),
  };

  const { response, engine } = await resolveResponse(trimmed, state);
  const sideEffects = executeSideEffects(response, state);

  const assistantMessage: ChatMessage = {
    id: uuidv4(),
    role: "assistant",
    content: response.message,
    timestamp: new Date().toISOString(),
    pendingAction: response.pendingAction,
    imageUrl:
      typeof response.data?.generatedImage === "string"
        ? response.data.generatedImage
        : undefined,
  };

  setState((s) => ({
    ...s,
    ...sideEffects,
    chatHistory: [...s.chatHistory, userMessage, assistantMessage],
  }));

  const turnCount = getState().chatHistory.length;
  if (turnCount > 0 && turnCount % 15 === 0) {
    const recent = getState()
      .chatHistory.slice(-6)
      .map((m) => `${m.role}: ${m.content.slice(0, 120)}`)
      .join(" | ");
    appendConversationSummary(recent);
  }

  const finalState = await clientAppState(getState());

  return NextResponse.json({
    message: assistantMessage,
    state: finalState,
    speak: response.speak,
    engine,
  });
}

export async function GET() {
  const state = await getEnrichedState();
  return NextResponse.json({ history: state.chatHistory });
}

export async function DELETE() {
  clearChatHistory();
  return NextResponse.json({ ok: true });
}
