import type {
  FinancingPlan,
  InventoryItem,
  ManagerTier,
  PaymentMethod,
  PricingResult,
  ProductCategory,
  TierPricing,
} from "./types";

const TIER_LABELS: Record<ManagerTier, string> = {
  dm: "District Manager (DM)",
  cm: "Corporate Manager (CM)",
  m: "Manager (M)",
};

const WATCH_DISCOUNTS: Record<string, Record<ManagerTier, number>> = {
  ROLEX: { dm: 62, cm: 60, m: 60 },
  GUCCI: { dm: 15, cm: 15, m: 15 },
  RADO: { dm: 18, cm: 18, m: 18 },
  LONGINES: { dm: 18, cm: 18, m: 18 },
  MOVADO: { dm: 25, cm: 25, m: 25 },
  BULOVA: { dm: 25, cm: 25, m: 25 },
  "MICHAEL KO": { dm: 25, cm: 25, m: 25 },
  "G-SHOCK": { dm: 25, cm: 25, m: 25 },
};

/** Whole gold — one tier for all gold (no under/over 20g split). */
const GOLD_DISCOUNTS: Record<ManagerTier, number> = {
  dm: 65,
  cm: 60,
  m: 55,
};

const BENCHMARK_FAMILY_DISCOUNTS: Record<ManagerTier, number> = {
  dm: 65,
  cm: 60,
  m: 55,
};

const DIAMOND_DISCOUNTS: Record<ManagerTier, number> = {
  dm: 82,
  cm: 80,
  m: 77.5,
};

/** UV / Ultimate Value + diamond — flat 82% (except zero-discount SKUs). */
const UV_DIAMOND_DISCOUNTS: Record<ManagerTier, number> = {
  dm: 82,
  cm: 82,
  m: 82,
};

const ZERO_DISCOUNTS: Record<ManagerTier, number> = { dm: 0, cm: 0, m: 0 };

const FIXED_DESIGN_DISCOUNTS: Record<ManagerTier, number> = {
  dm: 20,
  cm: 15,
  m: 10,
};

const FIXED_DESIGN_LABELS: Record<string, string> = {
  LINKNLOCK: "Link N Lock",
  LOVE: "Love",
  OROVENTI: "Oroventi",
};

/** Departments that count as Diamond category (plus "diamond" in description). */
const DIAMOND_DEPARTMENTS = new Set([
  "BANGLE",
  "EARRINGS",
  "FANCY NECK",
  "GENTS RING",
  "LADYS RING",
  "LADYS BRCL",
  "MENS BRCLT",
  "PENDANT",
  "TRIO",
  "SOL RING",
]);

/**
 * UV / Ultimate Value + diamond → 0% for these SKUs (match Item # base before '-').
 */
const UV_DIAMOND_ZERO_SKUS = new Set([
  "231611",
  "231614",
  "231616",
  "231618",
  "231620",
  "231622",
  "231624",
  "230768",
  "232736",
]);

const GOLD_DEPTS = [
  "GOLD BANDS",
  "GOLD CHAIN",
  "GOLD HOOPS",
  "GOLD PNDTS",
  "GOLD ID",
  "GOLD RINGS",
];

function normalizeDept(dept: string): string {
  return dept.trim().toUpperCase();
}

function skuBase(sku: string): string {
  return sku.trim().toUpperCase().split(/[-\s]/)[0] ?? "";
}

function textBlob(item: InventoryItem): string {
  return [
    item.description,
    item.vendorModel,
    item.design,
    item.department,
    item.class,
    item.brand,
  ].join(" ");
}

function isGShock(item: InventoryItem): boolean {
  return /g[\s-]?shock/i.test(textBlob(item));
}

function isGold(item: InventoryItem): boolean {
  const dept = normalizeDept(item.department);
  if (GOLD_DEPTS.some((g) => dept.includes(g) || dept === g)) return true;
  if (/^GOLD JEWL$/i.test(item.design.trim())) return true;
  if (/GOLD/i.test(item.department)) return true;
  return false;
}

/** Gold weight still shown in UI; discounts no longer split on it. */
function getGoldAvgWeightGrams(item: InventoryItem): number {
  return item.avgWeight > 0 ? item.avgWeight : 0;
}

function getBenchmarkFamilyLabel(item: InventoryItem): string | null {
  const blob = textBlob(item);
  if (/benchmark/i.test(blob)) return "Benchmark";
  if (/triton/i.test(blob)) return "Triton";
  if (/tungsten/i.test(blob)) return "Tungsten";
  return null;
}

function isWatch(item: InventoryItem): boolean {
  if (isGShock(item)) return true;
  const dept = normalizeDept(item.department);
  if (dept in WATCH_DISCOUNTS) return true;
  if (dept.startsWith("MICHAEL")) return true;
  return dept === "WATCH";
}

function getWatchBrand(item: InventoryItem): string {
  if (isGShock(item)) return "G-SHOCK";
  const dept = normalizeDept(item.department);
  if (dept in WATCH_DISCOUNTS) return dept;
  if (dept.startsWith("MICHAEL")) return "MICHAEL KO";
  return dept;
}

function getWatchDiscountPercents(
  watchBrand: string,
  item: InventoryItem
): Record<ManagerTier, number> {
  return (
    WATCH_DISCOUNTS[watchBrand] ??
    WATCH_DISCOUNTS[normalizeDept(item.department)] ?? {
      dm: 0,
      cm: 0,
      m: 0,
    }
  );
}

function getFixedDesignCollection(item: InventoryItem): string | null {
  const design = item.design.trim().toUpperCase();
  return FIXED_DESIGN_LABELS[design] ?? null;
}

function isGemstone(item: InventoryItem): boolean {
  return /birthstone/i.test(item.subClass);
}

function hasUvOrUltimateValue(item: InventoryItem): boolean {
  if (/^UV$/i.test(item.class.trim())) return true;
  const desc = item.description ?? "";
  return /\buv\b/i.test(desc) || /ultimate\s*value/i.test(desc);
}

/**
 * DM Cost Price: Whole Cost normally.
 * Gold + UV / Ultimate Value (class or description) → Tag Price ÷ 1.3
 * (not gold ÷4, and not Whole÷1.3 which double-counts a ÷4 Whole Cost).
 */
export function getVisibleDmCostPrice(item: InventoryItem): number {
  if (isGold(item) && hasUvOrUltimateValue(item)) {
    const tag = Number(item.tagPrice) || 0;
    if (tag > 0) return tag / 1.3;
  }
  const base =
    Number(item.wholesaleCost) > 0
      ? Number(item.wholesaleCost)
      : Number(item.costPrice) || 0;
  return base;
}

function isUvGoldJewelZeroDiscount(item: InventoryItem): boolean {
  return (
    /^UV$/i.test(item.class.trim()) && /^GOLD JEWL$/i.test(item.design.trim())
  );
}

function isDiamondCategory(item: InventoryItem): boolean {
  if (/diamond/i.test(item.description ?? "")) return true;
  return DIAMOND_DEPARTMENTS.has(normalizeDept(item.department));
}

function isUvDiamondSpecial(item: InventoryItem): boolean {
  return hasUvOrUltimateValue(item) && isDiamondCategory(item);
}

function isUvDiamondZeroSku(item: InventoryItem): boolean {
  return UV_DIAMOND_ZERO_SKUS.has(skuBase(item.sku));
}

export function classifyProduct(item: InventoryItem): {
  category: ProductCategory;
  categoryLabel: string;
  watchBrand?: string;
  goldWeightGrams?: number;
} {
  if (isUvGoldJewelZeroDiscount(item)) {
    return { category: "other", categoryLabel: "UV Gold Jewel" };
  }

  if (isUvDiamondSpecial(item)) {
    return {
      category: "diamond_gemstone",
      categoryLabel: isUvDiamondZeroSku(item)
        ? "UV / Ultimate Value Diamond (no discount)"
        : "UV / Ultimate Value Diamond",
    };
  }

  if (isWatch(item)) {
    return {
      category: "watch",
      categoryLabel: "Watch",
      watchBrand: getWatchBrand(item),
    };
  }

  const fixedDesign = getFixedDesignCollection(item);
  if (fixedDesign) {
    return {
      category: "other",
      categoryLabel: fixedDesign,
    };
  }

  const metalBrand = getBenchmarkFamilyLabel(item);
  if (metalBrand) {
    return {
      category: "benchmark",
      categoryLabel: metalBrand,
    };
  }

  if (isGemstone(item)) {
    return {
      category: "diamond_gemstone",
      categoryLabel: "Gemstone Jewelry",
    };
  }

  if (isDiamondCategory(item)) {
    return {
      category: "diamond_gemstone",
      categoryLabel: "Diamond Jewelry",
    };
  }

  if (isGold(item)) {
    return {
      category: "gold",
      categoryLabel: "Gold",
      goldWeightGrams: getGoldAvgWeightGrams(item),
    };
  }

  return {
    category: "other",
    categoryLabel: "Jewelry",
  };
}

function getDiscountPercents(
  item: InventoryItem,
  category: ProductCategory,
  watchBrand?: string
): Record<ManagerTier, number> {
  if (isUvGoldJewelZeroDiscount(item)) {
    return ZERO_DISCOUNTS;
  }

  if (isUvDiamondSpecial(item)) {
    return isUvDiamondZeroSku(item) ? ZERO_DISCOUNTS : UV_DIAMOND_DISCOUNTS;
  }

  if (category === "watch" && watchBrand) {
    return getWatchDiscountPercents(watchBrand, item);
  }

  if (getFixedDesignCollection(item)) {
    return FIXED_DESIGN_DISCOUNTS;
  }

  if (category === "benchmark") {
    return BENCHMARK_FAMILY_DISCOUNTS;
  }

  if (category === "diamond_gemstone" || category === "other") {
    return DIAMOND_DISCOUNTS;
  }

  if (category === "gold") {
    return GOLD_DISCOUNTS;
  }

  return DIAMOND_DISCOUNTS;
}

function formatTierSummary(discounts: Record<ManagerTier, number>): string {
  const { dm, cm, m } = discounts;
  if (dm === cm && cm === m) return `${dm}% off (DM / CM / M)`;
  return `DM ${dm}%, CM ${cm}%, M ${m}% off`;
}

function buildRulesSummary(
  item: InventoryItem,
  category: ProductCategory,
  watchBrand?: string,
  goldWeightGrams?: number,
  discounts?: Record<ManagerTier, number>
): string {
  if (!discounts) return "";

  if (isUvGoldJewelZeroDiscount(item)) {
    return "Class UV + Design GOLD JEWL — 0% discount";
  }

  if (isUvDiamondSpecial(item)) {
    if (isUvDiamondZeroSku(item)) {
      return `UV / Ultimate Value + diamond (SKU ${skuBase(item.sku)}) — 0% discount`;
    }
    return "UV / Ultimate Value + diamond — 82% off (DM / CM / M)";
  }

  const fixedDesign = getFixedDesignCollection(item);
  if (fixedDesign) {
    return `${fixedDesign} — ${formatTierSummary(discounts)}`;
  }

  if (category === "watch" && watchBrand) {
    return `${watchBrand} watch — ${formatTierSummary(discounts)}`;
  }

  if (category === "benchmark") {
    const label = getBenchmarkFamilyLabel(item) ?? "Benchmark";
    return `${label} — ${formatTierSummary(discounts)}`;
  }

  if (category === "diamond_gemstone") {
    return `Diamond / Gemstone — ${formatTierSummary(discounts)}`;
  }

  if (category === "gold") {
    const weight = goldWeightGrams ?? 0;
    const weightLabel =
      weight > 0 ? `${weight}g avg weight — ` : "avg weight not set — ";
    return `Gold (${weightLabel}whole gold) — ${formatTierSummary(discounts)}`;
  }

  return `Standard jewelry — ${formatTierSummary(discounts)}`;
}

export function calculatePricing(item: InventoryItem): PricingResult {
  const { category, categoryLabel, watchBrand, goldWeightGrams } =
    classifyProduct(item);
  const discountPercents = getDiscountPercents(item, category, watchBrand);

  const tiers: TierPricing[] = (["dm", "cm", "m"] as ManagerTier[]).map(
    (tier) => {
      const discountPercent = discountPercents[tier];
      return {
        tier,
        label: TIER_LABELS[tier],
        discountPercent,
        cashPrice: item.tagPrice * (1 - discountPercent / 100),
      };
    }
  );

  return {
    category,
    categoryLabel,
    watchBrand,
    goldWeightGrams,
    tagPrice: item.tagPrice,
    tiers,
    rulesSummary: buildRulesSummary(
      item,
      category,
      watchBrand,
      goldWeightGrams,
      discountPercents
    ),
  };
}

/** Allowed off-tag % for a manager tier (single source: same rules as calculator). */
export function getAllowedDiscountPercent(
  item: InventoryItem,
  tier: ManagerTier
): number {
  const pricing = calculatePricing(item);
  return pricing.tiers.find((t) => t.tier === tier)?.discountPercent ?? 0;
}

export const CREDIT_CARD_SURCHARGE_PERCENT = 3.5;

export const FINANCING_PLAN_SURCHARGES: Record<FinancingPlan, number> = {
  "6_months": 3.5,
  "12_months": 7,
  "18_months": 12,
  "24_months": 18,
  "36_months": 22,
  "48_months": 28,
  "60_months": 32,
};

export const FINANCING_PLAN_LABELS: Record<FinancingPlan, string> = {
  "6_months": "06 Months No Interest — 3.5%",
  "12_months": "12 Months No Interest — 7%",
  "18_months": "18 Months No Interest — 12%",
  "24_months": "24 Months No Interest — 18%",
  "36_months": "36 Months No Interest — 22%",
  "48_months": "48 Months No Interest — 28%",
  "60_months": "60 Months No Interest — 32%",
};

/** Progressive / Acima / UOwn / Kefene — fixed 5%. */
export const LEASE_SURCHARGE_PERCENT = 5;

export const AFFIRM_SURCHARGE_PERCENT = 12;

export function calculateFinancedPrice(
  cashPrice: number,
  paymentMethod: PaymentMethod,
  financingPlan: FinancingPlan
): { surchargePercent: number; financedPrice: number } {
  if (paymentMethod === "cash") {
    return { surchargePercent: 0, financedPrice: cashPrice };
  }

  let surchargePercent = 0;
  if (paymentMethod === "credit_card") {
    surchargePercent = CREDIT_CARD_SURCHARGE_PERCENT;
  } else if (paymentMethod === "financing") {
    surchargePercent = FINANCING_PLAN_SURCHARGES[financingPlan];
  } else if (paymentMethod === "lease") {
    surchargePercent = LEASE_SURCHARGE_PERCENT;
  } else if (paymentMethod === "affirm") {
    surchargePercent = AFFIRM_SURCHARGE_PERCENT;
  }

  return {
    surchargePercent,
    financedPrice: cashPrice * (1 + surchargePercent / 100),
  };
}

export function calculateGrandTotal(
  financedPrice: number,
  commission: number,
  commissionPlus: number
): number {
  return financedPrice + commission + commissionPlus;
}
