/**
 * Canonical map of every Alexa app section — routes, tools, and response guidance.
 */

export type AppSectionId =
  | "chat"
  | "news"
  | "email"
  | "calendar"
  | "sales"
  | "stores"
  | "calculator"
  | "discounting"
  | "analyst"
  | "images"
  | "contacts"
  | "social"
  | "settings";

export interface AppSectionDefinition {
  id: AppSectionId;
  label: string;
  route: string;
  purpose: string;
  availableData: string[];
  relatedTools: string[];
  commonQuestions: string[];
  whenToNavigate: string;
  whenToClarify: string;
  whenToUseLiveTool: string;
  exampleResponses: Record<string, string>;
  /** Keywords for matching user questions about this section */
  aliases: string[];
}

const section = (
  def: Omit<AppSectionDefinition, "aliases"> & { aliases?: string[] }
): AppSectionDefinition => ({
  ...def,
  aliases: def.aliases ?? [def.label.toLowerCase(), def.id],
});

export const APP_SECTIONS: Record<AppSectionId, AppSectionDefinition> = {
  chat: section({
    id: "chat",
    label: "AI Chat",
    route: "/chat",
    purpose:
      "Executive command center — ask anything, draft emails, schedule meetings, and get focused answers without leaving chat.",
    availableData: [
      "Chat history",
      "Pending email/meeting confirmations",
      "Voice assistant",
      "Quick-action suggestions",
    ],
    relatedTools: [
      "get_today_sales",
      "get_email_summary",
      "get_calendar_today",
      "draft_email_reply",
      "add_meeting",
      "get_industry_news",
      "search_company_knowledge",
    ],
    commonQuestions: [
      "Draft an email to Ross",
      "What's my top store?",
      "Schedule a meeting tomorrow",
      "Summarize my inbox",
    ],
    whenToNavigate:
      "When user wants a dedicated workspace (full inbox, calendar grid, sales charts) instead of chat.",
    whenToClarify:
      "When intent is ambiguous between read vs write (e.g. 'email' could mean inbox summary or compose).",
    whenToUseLiveTool:
      "Always call the relevant tool before answering live sales, inbox, or calendar questions.",
    exampleResponses: {
      greeting:
        "I'm Alexa, your executive assistant. Ask me about sales, email, calendar, news, or say what you'd like done.",
      capabilities:
        "Here I can answer questions, draft emails, schedule meetings, and pull live sales or inbox data — all in one place.",
    },
    aliases: ["ai chat", "chat", "assistant", "alexa"],
  }),

  news: section({
    id: "news",
    label: "News & Markets",
    route: "/news",
    purpose:
      "Jewelry industry headlines plus live gold/silver rates and market charts (stocks, sports, politics tabs).",
    availableData: [
      "Industry RSS headlines",
      "Live gold & silver spot rates",
      "Market / sports / politics news tabs",
      "Calculator-linked metal prices",
    ],
    relatedTools: [
      "get_industry_news",
      "get_metal_rates",
      "get_sports_news",
      "get_politics_news",
    ],
    commonQuestions: [
      "What's happening in jewelry news?",
      "Gold price today?",
      "Open industry headlines",
    ],
    whenToNavigate: "When user wants full charts, tabs, or live scrolling headlines.",
    whenToClarify: "When user says 'markets' — clarify industry vs stocks vs metals.",
    whenToUseLiveTool: "Call get_industry_news or get_metal_rates — never guess prices.",
    exampleResponses: {
      explain:
        "**News & Markets** covers jewelry industry headlines, live **gold/silver** prices, and tabs for markets, sports, and politics. Say **open news** for the full page.",
      capabilities:
        "Here I can fetch industry headlines, live gold and silver rates, and summarize market news. Try *what's gold at today?* or *jewelry industry news*.",
    },
    aliases: [
      "news",
      "news and markets",
      "markets",
      "market",
      "gold",
      "silver",
      "industry news",
    ],
  }),

  email: section({
    id: "email",
    label: "Email",
    route: "/email",
    purpose:
      "Gmail-connected inbox — read, prioritize urgent mail, and draft/send replies with confirmation.",
    availableData: [
      "Inbox threads (Gmail or demo)",
      "Selected email context",
      "Unread / urgent / needs-reply flags",
      "Draft pending actions",
    ],
    relatedTools: ["get_email_summary", "draft_email_reply", "compose_email_to"],
    commonQuestions: [
      "Any urgent emails?",
      "Reply to this",
      "Send email to Ross about the meeting",
      "Summarize inbox",
    ],
    whenToNavigate: "When user needs to browse threads or read full HTML bodies.",
    whenToClarify:
      "When no email is selected and user says 'reply to this' — ask which thread or offer inbox summary.",
    whenToUseLiveTool:
      "Call get_email_summary for counts; draft_email_reply for thread replies; compose_email_to for new mail to a named person/address.",
    exampleResponses: {
      explain:
        "This is your **Email** workspace — threaded inbox with urgent flags and context-aware reply drafting. Select a thread, then say **reply to this**.",
      capabilities:
        "Here I can summarize unread mail, open full threads, surface urgent items, and draft replies using the whole conversation. Select a thread first for *reply to this*.",
      replyNoSelection:
        "Select a thread on the left first, then say **reply to this** — or tell me who to email (e.g. *send email to Ross*).",
    },
    aliases: ["email", "inbox", "mail", "gmail"],
  }),

  calendar: section({
    id: "calendar",
    label: "Calendar & Tasks",
    route: "/calendar",
    purpose:
      "Google Calendar meetings plus internal tasks/reminders — view, schedule, and cancel with confirmation.",
    availableData: [
      "Today's and upcoming events",
      "Selected meeting",
      "Pending tasks / reminders",
      "Meeting create/cancel pending actions",
    ],
    relatedTools: [
      "get_calendar_today",
      "list_tasks",
      "add_meeting",
      "delete_meeting",
      "delete_all_meetings",
      "add_task",
      "delete_task",
    ],
    commonQuestions: [
      "What's on my calendar?",
      "Schedule meeting with Ross tomorrow",
      "Remove all meetings",
      "My tasks",
    ],
    whenToNavigate: "When user wants the full calendar grid or task list UI.",
    whenToClarify:
      "Bulk delete vs single meeting; missing time or attendee for new meetings.",
    whenToUseLiveTool:
      "Call get_calendar_today / list_tasks for live schedule; stage dangerous deletes.",
    exampleResponses: {
      explain:
        "**Calendar & Tasks** shows meetings and to-dos. I can list today's schedule, book meetings, or remove events — destructive actions need your **yes** to confirm.",
      capabilities:
        "Here I can list today's meetings and tasks, schedule new meetings, or cancel events. Try *what's on my calendar?* or *set meeting with Ross tomorrow*.",
    },
    aliases: ["calendar", "tasks", "meetings", "schedule", "calender"],
  }),

  sales: section({
    id: "sales",
    label: "Sales Dashboard",
    route: "/sales",
    purpose:
      "Store-level POS sales from uploaded CSV — revenue, top stores/products, and trends.",
    availableData: [
      "Latest uploaded sales report",
      "Top stores & products",
      "Net/gross revenue and discounts",
      "Selected report metadata",
    ],
    relatedTools: ["get_today_sales", "open_data_analyst"],
    commonQuestions: [
      "Best store?",
      "Top products?",
      "Full sales report",
      "Explain this dashboard",
    ],
    whenToNavigate: "When user wants charts and tables beyond a chat summary.",
    whenToClarify: "When user says 'sales' but means analyst CSV vs dashboard report.",
    whenToUseLiveTool:
      "Call get_today_sales with focus top_store | summary | full_report — pass user_message so dates like '8 July' filter to that day. Default to short answers.",
    exampleResponses: {
      explain:
        "**Sales Dashboard** shows your latest uploaded report — net revenue, top stores, and products. Ask *best store?* for a short answer or *full report* for everything.",
      capabilities:
        "Here I can tell you top stores, revenue, and product leaders from your latest report. Try *best store with sales?* — I'll keep it concise unless you ask for a full breakdown.",
    },
    aliases: [
      "sales today",
      "sales dashboard",
      "sales",
      "revenue",
      "pos",
    ],
  }),

  stores: section({
    id: "stores",
    label: "Stores Map & Info",
    route: "/stores",
    purpose:
      "Interactive map of all Valliani Jewelers locations — mall names, addresses, phones, hours, and Google ratings/reviews.",
    availableData: [
      "31 synced store locations with lat/lng",
      "Addresses, phones, opening hours (US local time)",
      "Google Maps ratings & reviews (via npm run stores:reviews)",
      "Google Maps / Apple Maps links",
      "State and city filters",
    ],
    relatedTools: ["get_store_directory", "show_detail_page"],
    commonQuestions: [
      "Open stores map",
      "Where is the Roseville store?",
      "Show all California locations",
      "Store phone numbers",
    ],
    whenToNavigate:
      "When user wants the map UI, store locator, or to browse locations visually.",
    whenToClarify: "When asking about a store without naming mall/city — ask which location.",
    whenToUseLiveTool:
      "Call get_store_directory for address/phone/hours answers; navigate to /stores for the map.",
    exampleResponses: {
      explain:
        "**Stores Map & Info** shows every Valliani location on a map with address, phone, and hours. Ratings and Google reviews will be added later.",
      capabilities:
        "I can look up any store's address, phone, or hours, or open the **Stores Map** so you can browse pins by state.",
    },
    aliases: [
      "stores and map",
      "stores map",
      "store map",
      "store locator",
      "locations",
      "store locations",
      "find a store",
      "stores map and info",
      "stores",
    ],
  }),

  calculator: section({
    id: "calculator",
    label: "Price Calculator",
    route: "/calculator",
    purpose:
      "Jewelry pricing — estimate piece value from weight, karat, making charges, and live gold/silver rates.",
    availableData: [
      "Live gold/silver spot rates",
      "Karat and making-charge presets",
      "Estimated totals",
    ],
    relatedTools: ["get_metal_rates", "estimate_jewellery_price"],
    commonQuestions: [
      "Price a 22K gold chain",
      "What's gold per gram?",
      "Estimate 10g ring",
    ],
    whenToNavigate: "When user wants the interactive calculator UI with sliders.",
    whenToClarify: "Missing weight, karat, or metal type for estimates.",
    whenToUseLiveTool: "Call get_metal_rates or estimate_jewellery_price with user specs.",
    exampleResponses: {
      explain:
        "**Price Calculator** estimates jewelry value using live metal rates, karat, weight, and making charges. Open the page to adjust inputs, or tell me weight and karat here.",
      capabilities:
        "Here I can quote live gold/silver rates and estimate a piece (e.g. *10 grams 22K gold chain*). For full controls, open the calculator page.",
    },
    aliases: ["calculator", "price calculator", "pricing", "gold price", "estimate"],
  }),

  discounting: section({
    id: "discounting",
    label: "Discounting",
    route: "/discounting",
    purpose:
      "Flag high discounts where Disc Amt % exceeds Price Calculator allowed % for Manager, Corporate Manager, and District Manager approvers.",
    availableData: [
      "Live sales Disc Amt vs Sales Amount",
      "APP / FIN description approver codes",
      "Pay Code channel (cash / CC / financing / lease / Affirm)",
      "Calculator DM/CM/M allowed % by SKU rules",
    ],
    relatedTools: ["get_high_discounts"],
    commonQuestions: [
      "High discounts today",
      "Any excessive discounts?",
      "Show discounting exceptions",
    ],
    whenToNavigate: "When user wants the high-discount table / filters.",
    whenToClarify: "When date is unclear — default to latest sales day.",
    whenToUseLiveTool: "Call get_high_discounts for the list; open /discounting.",
    exampleResponses: {
      explain:
        "**Discounting** compares each sale’s discount % to the Price Calculator limit for the approving Manager / CM / DM. Over-limit lines appear here and in chat.",
      capabilities:
        "Ask *high discounts today* and I’ll list overages, or open **Discounting** for the full table.",
    },
    aliases: [
      "discounting",
      "high discounts",
      "excessive discounts",
      "discount exceptions",
    ],
  }),

  analyst: section({
    id: "analyst",
    label: "Data Analyst",
    route: "/analyst",
    purpose:
      "Upload any sales CSV and query it with natural language — DuckDB SQL, charts, trends, and forecasts.",
    availableData: [
      "Uploaded CSV datasets",
      "DuckDB in-browser analytics",
      "Generated SQL and chart specs",
      "Schema inference",
    ],
    relatedTools: ["open_data_analyst"],
    commonQuestions: [
      "What is data analyst?",
      "Analyze my CSV",
      "Top products last month",
      "Forecast next week",
    ],
    whenToNavigate:
      "When user needs to upload a file, run SQL, or see interactive charts.",
    whenToClarify: "When no CSV is loaded — prompt user to upload first.",
    whenToUseLiveTool:
      "Direct simple sales questions to get_today_sales; complex analysis → open_data_analyst / analyst page.",
    exampleResponses: {
      explain:
        "**Data Analyst** lets you upload a sales CSV and ask questions in plain English. It runs **DuckDB** queries, builds charts, and supports trends and forecasts — upload a file on the Analyst page to start.",
      capabilities:
        "Here you upload CSV data and ask anything — top SKUs, monthly trends, store comparisons. For today's bundled report, use Sales Dashboard; for custom files, open **Data Analyst**.",
    },
    aliases: ["data analyst", "analyst", "csv", "duckdb", "sql", "upload"],
  }),

  images: section({
    id: "images",
    label: "Image Generation",
    route: "/images",
    purpose:
      "AI jewelry product imagery — generate rings, necklaces, and campaign visuals from descriptions.",
    availableData: [
      "Generated image gallery",
      "Last prompt and result",
      "Gemini / OpenAI image APIs",
    ],
    relatedTools: ["generate_jewellery_image"],
    commonQuestions: [
      "Generate a gold bridal necklace",
      "Create ring image",
      "Show my generations",
    ],
    whenToNavigate: "When user wants the gallery or fine-tune prompts visually.",
    whenToClarify: "When prompt is too vague — ask metal, stones, style.",
    whenToUseLiveTool: "Call generate_jewellery_image with a detailed prompt.",
    exampleResponses: {
      explain:
        "**Image Generation** creates AI jewelry photos from your description — rings, necklaces, bridal sets. Open the page to browse past images or say *generate a platinum oval diamond ring*.",
      capabilities:
        "Here I can generate product-style jewelry images from a text prompt. Describe metal, stones, and style — or open the gallery on the Image Generation page.",
    },
    aliases: ["images", "image generation", "generate", "ai image", "jewelry photo"],
  }),

  contacts: section({
    id: "contacts",
    label: "Contacts",
    route: "/contacts",
    purpose:
      "Executive rolodex — team, vendors, and key partners with phone, email, and WhatsApp.",
    availableData: [
      "Contact names, roles, companies",
      "Phone / email / WhatsApp",
      "Selected contact",
      "Important contact flags",
    ],
    relatedTools: ["list_contacts"],
    commonQuestions: [
      "Find Ross",
      "Lisa's phone number",
      "Who is my GM?",
    ],
    whenToNavigate: "When user wants to browse or edit the full contact list.",
    whenToClarify: "Ambiguous names — ask which Ross or role.",
    whenToUseLiveTool: "Call list_contacts with query — never invent numbers.",
    exampleResponses: {
      explain:
        "**Contacts** stores your key people — leadership, store managers, vendors. Ask *find Ross* or select someone here for email/meeting actions.",
      capabilities:
        "Here I can look up names, roles, and phone numbers. Try *find [name]* or open the full directory.",
    },
    aliases: ["contacts", "contact", "phone", "rolodex", "people"],
  }),

  social: section({
    id: "social",
    label: "Social",
    route: "/social",
    purpose:
      "Instagram Business command center — followers, recent posts, comments, and post insights from the Meta Graph API, plus AI caption and reply drafting.",
    availableData: [
      "Instagram account profile (followers, media count)",
      "Recent posts with likes and comments",
      "Comments on selected posts",
      "Post insights (reach, impressions, engagement)",
    ],
    relatedTools: [
      "get_instagram_account",
      "get_instagram_recent_posts",
      "get_instagram_post_comments",
      "get_instagram_post_insights",
      "draft_instagram_caption",
      "draft_instagram_comment_reply",
    ],
    commonQuestions: [
      "How many Instagram followers do I have?",
      "Show my latest Instagram posts",
      "Comments on the latest post",
      "How did my last post perform?",
    ],
    whenToNavigate: "When user wants the full Instagram dashboard with post grid and detail panel.",
    whenToClarify: "When it's unclear which post the user means — offer recent posts first.",
    whenToUseLiveTool:
      "Call get_instagram_* tools for live data. Captions/replies are DRAFT ONLY — never publish or auto-reply.",
    exampleResponses: {
      explain:
        "**Social** is your Instagram Business dashboard — followers, recent posts, comments, and performance insights, with AI help to draft captions and replies. Publishing stays manual.",
      capabilities:
        "Here I can show your Instagram followers, recent posts, comments, and post insights, and draft captions or replies for you. I never publish or reply automatically.",
    },
    aliases: ["social", "instagram", "insta", "social media"],
  }),

  settings: section({
    id: "settings",
    label: "Settings",
    route: "/settings",
    purpose:
      "Profile, Google/Plaid integrations, confirmation preferences, and assistant behavior.",
    availableData: [
      "User profile & role",
      "Google Gmail/Calendar connection",
      "Confirm-before-send preferences",
      "Timezone & communication style",
    ],
    relatedTools: ["get_settings_status", "show_detail_page", "search_company_knowledge"],
    commonQuestions: [
      "Connect Gmail",
      "Turn off confirm before send",
      "Update my profile",
    ],
    whenToNavigate: "When user needs toggles, OAuth, or profile forms.",
    whenToClarify: "Distinguish account settings vs company policy questions.",
    whenToUseLiveTool:
      "Company policy → search_company_knowledge; account changes → direct to Settings UI.",
    exampleResponses: {
      explain:
        "**Settings** manages your profile, Google connection, and confirmation preferences (email, meetings, calls). Open the page to connect Gmail or adjust how I ask before sending.",
      capabilities:
        "Here you connect Google, set confirm-before-send rules, and update your executive profile. For company policies, ask me directly — for account toggles, use this page.",
    },
    aliases: ["settings", "preferences", "profile", "connect google", "integration"],
  }),
};

export const APP_SECTION_LIST = Object.values(APP_SECTIONS);

/** Resolve section from URL path (handles query strings). */
export function sectionForPath(path: string): AppSectionDefinition {
  const base = path.split("?")[0] || "/chat";
  const found = APP_SECTION_LIST.find(
    (s) => s.route === base || (base !== "/" && base.startsWith(s.route))
  );
  return found ?? APP_SECTIONS.chat;
}

/** Match user text to a section by label, alias, or id. */
export function sectionFromMessage(message: string): AppSectionDefinition | null {
  const lower = message.toLowerCase();
  for (const sec of APP_SECTION_LIST) {
    if (sec.aliases.some((a) => lower.includes(a))) return sec;
  }
  return null;
}

export function sectionIdFromPath(path: string): AppSectionId {
  return sectionForPath(path).id;
}

/** Short spoken line when opening a section — no summary. */
export const SECTION_OPEN_SPOKEN: Record<AppSectionId, string> = {
  sales: "Opening Sales Dashboard.",
  news: "Opening News and Markets.",
  chat: "Opening AI Chat.",
  email: "Opening Email.",
  calendar: "Opening Calendar.",
  stores: "Opening Stores Map and Info.",
  calculator: "Opening Price Calculator.",
  analyst: "Opening Data Analyst.",
  images: "Opening Image Generation.",
  social: "Opening Social.",
  contacts: "Opening Contacts.",
  settings: "Opening Settings.",
  discounting: "Opening Discounting.",
};

export function openingSpokenForSection(sectionId: string): string {
  const id = sectionId as AppSectionId;
  if (SECTION_OPEN_SPOKEN[id]) return SECTION_OPEN_SPOKEN[id];
  const sec = APP_SECTIONS[id];
  return sec ? `Opening ${sec.label}.` : `Opening ${sectionId}.`;
}

/** Resolve navigation target from open/go-to phrases (longest aliases first). */
export function resolveOpenSectionId(message: string): AppSectionId | null {
  const lower = message.toLowerCase().trim();
  if (!lower) return null;

  /** Too ambiguous for navigation matching alone. */
  const weak = new Set([
    "gold",
    "silver",
    "market",
    "csv",
    "generate",
    "pos",
    "mail",
    "assistant",
    "alexa",
    "pricing",
    "estimate",
    "upload",
    "sql",
    "duckdb",
  ]);

  const scored: { id: AppSectionId; len: number }[] = [];
  for (const sec of APP_SECTION_LIST) {
    for (const alias of sec.aliases) {
      const a = alias.toLowerCase();
      if (a.length < 3 || weak.has(a)) continue;
      if (lower.includes(a)) scored.push({ id: sec.id, len: a.length });
    }
    if (new RegExp(`\\b${sec.id}\\b`).test(lower)) {
      scored.push({ id: sec.id, len: sec.id.length + 10 });
    }
  }
  if (scored.length === 0) return null;
  scored.sort((a, b) => b.len - a.len);
  return scored[0].id;
}
